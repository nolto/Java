package kr.co.mission.product;

import static kr.co.mission.util.Variable.*;

public class Dryer extends Product {
	public Dryer() {
		setName(DRYER);
		setPrice(DRYER_PRICE);
	}

}
